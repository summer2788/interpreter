let rec fold3 combiner accum lst1 lst2 lst3 = 
  match (lst1, lst2, lst3) with
  | [], [], [] -> accum
  | h1::t1, h2::t2, h3::t3 -> fold3 combiner (combiner accum h1 h2 h3) t1 t2 t3
  | _ -> failwith "Lists are of different lengths!"


