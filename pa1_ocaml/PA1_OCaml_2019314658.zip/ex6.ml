let summation (start_point, end_point, func) =
  let rec iter_sum accumulator current =
    if current > end_point then accumulator
    else iter_sum (accumulator + func current) (current + 1)
  in
  if start_point > end_point then 0 else iter_sum 0 start_point
