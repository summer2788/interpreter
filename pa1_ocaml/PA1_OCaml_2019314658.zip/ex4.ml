
let rec merge list1 list2 = match list1, list2 with
  |  [],  _  -> list2
  |  _,  []  -> list1
  |  h0::t0, h1::t1  ->
    if h0 > h1 then h0 :: merge t0 list2
     else h1 :: merge list1 t1


