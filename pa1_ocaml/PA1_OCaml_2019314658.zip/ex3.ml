
let rec gcd x y =
  if y = 0 then x else gcd y (x mod y)

(* Euler's Totient function *)
let phi a = let rec count acc b =
    if b < a then
      let next_acc = if gcd a b = 1 then acc + 1 else acc in
      count next_acc (b + 1)
    else
      acc
  in
  count 0 1  (* Start counting from 1 as per the given range *)


